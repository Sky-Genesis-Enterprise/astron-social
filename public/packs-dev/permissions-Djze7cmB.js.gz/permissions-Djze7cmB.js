const E=1024,I=256,A=32,R=16;function O(S){return(S&8)===8}function _(S){return(S&16)===16}export{E as P,O as a,A as b,_ as c,R as d,I as e};
//# sourceMappingURL=permissions-Djze7cmB.js.map
