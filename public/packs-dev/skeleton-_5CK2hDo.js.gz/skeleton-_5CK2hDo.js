import{j as o}from"./client-BG6VvM0b.js";const n=({width:e,height:s})=>o.jsxDEV("span",{className:"skeleton",style:{width:e,height:s},children:"‌"},void 0,!1,{fileName:"/home/liam-esia/Bureau/github/mastodon/app/javascript/mastodon/components/skeleton.tsx",lineNumber:7,columnNumber:1},void 0);export{n as S};
//# sourceMappingURL=skeleton-_5CK2hDo.js.map
