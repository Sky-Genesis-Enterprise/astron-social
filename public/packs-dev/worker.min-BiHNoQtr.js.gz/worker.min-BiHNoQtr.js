const s="/packs-dev/assets/worker-B9Bty8gg.js";export{s as default};
//# sourceMappingURL=worker.min-BiHNoQtr.js.map
