import{r as t}from"./index-ykyyQSL-.js";const o=e=>t.createElement("svg",{xmlns:"http://www.w3.org/2000/svg",height:24,viewBox:"0 -960 960 960",width:24,...e},t.createElement("path",{d:"m256-200-56-56 224-224-224-224 56-56 224 224 224-224 56 56-224 224 224 224-56 56-224-224-224 224Z"}));export{o as S};
//# sourceMappingURL=close-DPVxbBbs.js.map
