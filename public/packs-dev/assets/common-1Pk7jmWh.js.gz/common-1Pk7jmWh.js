import{R as t}from"../rails-ujs.esm-DLwK8N9E.js";function a(){try{t.start()}catch{}}a();
//# sourceMappingURL=common-1Pk7jmWh.js.map
