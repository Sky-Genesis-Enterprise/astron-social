const e="/packs-dev/assets/elephant_ui_plane-Cfmrathl.svg";export{e};
//# sourceMappingURL=elephant_ui_plane-B72fsiXe.js.map
