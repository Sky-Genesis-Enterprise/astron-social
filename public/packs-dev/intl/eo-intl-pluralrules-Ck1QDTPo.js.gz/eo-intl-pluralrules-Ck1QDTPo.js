Intl.PluralRules&&typeof Intl.PluralRules.__addLocaleData=="function"&&Intl.PluralRules.__addLocaleData({data:{categories:{cardinal:["one","other"],ordinal:["other"]},fn:function(a,e){return e?"other":a==1?"one":"other"}},locale:"eo"});
//# sourceMappingURL=eo-intl-pluralrules-Ck1QDTPo.js.map
