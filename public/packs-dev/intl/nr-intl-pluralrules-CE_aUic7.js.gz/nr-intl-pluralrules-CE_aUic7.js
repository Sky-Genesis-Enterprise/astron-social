Intl.PluralRules&&typeof Intl.PluralRules.__addLocaleData=="function"&&Intl.PluralRules.__addLocaleData({data:{categories:{cardinal:["one","other"],ordinal:["other"]},fn:function(a,l){return l?"other":a==1?"one":"other"}},locale:"nr"});
//# sourceMappingURL=nr-intl-pluralrules-CE_aUic7.js.map
