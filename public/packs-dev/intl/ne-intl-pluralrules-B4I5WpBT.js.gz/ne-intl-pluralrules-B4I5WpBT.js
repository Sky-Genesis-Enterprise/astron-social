Intl.PluralRules&&typeof Intl.PluralRules.__addLocaleData=="function"&&Intl.PluralRules.__addLocaleData({data:{categories:{cardinal:["one","other"],ordinal:["one","other"]},fn:function(e,a){var l=String(e).split("."),t=Number(l[0])==e;return a?t&&e>=1&&e<=4?"one":"other":e==1?"one":"other"}},locale:"ne"});
//# sourceMappingURL=ne-intl-pluralrules-B4I5WpBT.js.map
