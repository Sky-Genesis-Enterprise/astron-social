Intl.PluralRules&&typeof Intl.PluralRules.__addLocaleData=="function"&&Intl.PluralRules.__addLocaleData({data:{categories:{cardinal:["one","other"],ordinal:["other"]},fn:function(a,t){var l=String(a).split("."),e=l[0],r=l[1]||"";return t?"other":a==0||a==1||e==0&&r==1?"one":"other"}},locale:"si"});
//# sourceMappingURL=si-intl-pluralrules-DsdC4m4b.js.map
