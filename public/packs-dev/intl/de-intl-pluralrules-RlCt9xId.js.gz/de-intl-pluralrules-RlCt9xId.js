Intl.PluralRules&&typeof Intl.PluralRules.__addLocaleData=="function"&&Intl.PluralRules.__addLocaleData({data:{categories:{cardinal:["one","other"],ordinal:["other"]},fn:function(a,l){var e=String(a).split("."),t=!e[1];return l?"other":a==1&&t?"one":"other"}},locale:"de"});
//# sourceMappingURL=de-intl-pluralrules-RlCt9xId.js.map
