Intl.PluralRules&&typeof Intl.PluralRules.__addLocaleData=="function"&&Intl.PluralRules.__addLocaleData({data:{categories:{cardinal:["one","two","other"],ordinal:["other"]},fn:function(a,e){return e?"other":a==1?"one":a==2?"two":"other"}},locale:"se"});
//# sourceMappingURL=se-intl-pluralrules-DDhhoU-V.js.map
