Intl.PluralRules&&typeof Intl.PluralRules.__addLocaleData=="function"&&Intl.PluralRules.__addLocaleData({data:{categories:{cardinal:["one","other"],ordinal:["other"]},fn:function(t,a){var l=String(t).split("."),e=Number(l[0])==t;return a?"other":t==0||t==1||e&&t>=11&&t<=99?"one":"other"}},locale:"tzm"});
//# sourceMappingURL=tzm-intl-pluralrules-C6q68dde.js.map
