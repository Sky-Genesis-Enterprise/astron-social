Intl.PluralRules&&typeof Intl.PluralRules.__addLocaleData=="function"&&Intl.PluralRules.__addLocaleData({data:{categories:{cardinal:["one","other"],ordinal:["other"]},fn:function(l,a){return a?"other":l==1?"one":"other"}},locale:"kl"});
//# sourceMappingURL=kl-intl-pluralrules-DDM7dKaW.js.map
