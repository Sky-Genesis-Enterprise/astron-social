Intl.PluralRules&&typeof Intl.PluralRules.__addLocaleData=="function"&&Intl.PluralRules.__addLocaleData({data:{categories:{cardinal:["one","other"],ordinal:["one","two","few","other"]},fn:function(e,a){return a?e==1?"one":e==2||e==3?"two":e==4?"few":"other":e==1?"one":"other"}},locale:"mr"});
//# sourceMappingURL=mr-intl-pluralrules-DkqkdnWJ.js.map
