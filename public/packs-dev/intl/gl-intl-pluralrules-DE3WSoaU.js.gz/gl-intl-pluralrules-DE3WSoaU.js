Intl.PluralRules&&typeof Intl.PluralRules.__addLocaleData=="function"&&Intl.PluralRules.__addLocaleData({data:{categories:{cardinal:["one","other"],ordinal:["other"]},fn:function(l,a){var t=String(l).split("."),e=!t[1];return a?"other":l==1&&e?"one":"other"}},locale:"gl"});
//# sourceMappingURL=gl-intl-pluralrules-DE3WSoaU.js.map
