Intl.PluralRules&&typeof Intl.PluralRules.__addLocaleData=="function"&&Intl.PluralRules.__addLocaleData({data:{categories:{cardinal:["one","few","other"],ordinal:["other"]},fn:function(e,a){var l=String(e).split("."),t=Number(l[0])==e;return a?"other":e>=0&&e<=1?"one":t&&e>=2&&e<=10?"few":"other"}},locale:"shi"});
//# sourceMappingURL=shi-intl-pluralrules-DvzHc8it.js.map
