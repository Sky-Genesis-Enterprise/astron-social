Intl.PluralRules&&typeof Intl.PluralRules.__addLocaleData=="function"&&Intl.PluralRules.__addLocaleData({data:{categories:{cardinal:["one","other"],ordinal:["other"]},fn:function(a,l){return l?"other":a==1?"one":"other"}},locale:"nn"});
//# sourceMappingURL=nn-intl-pluralrules-DaOK7SYc.js.map
