Intl.PluralRules&&typeof Intl.PluralRules.__addLocaleData=="function"&&Intl.PluralRules.__addLocaleData({data:{categories:{cardinal:["one","few","many","other"],ordinal:["other"]},fn:function(e,n){var l=String(e).split("."),t=l[0],a=!l[1];return n?"other":e==1&&a?"one":t>=2&&t<=4&&a?"few":a?"other":"many"}},locale:"cs"});
//# sourceMappingURL=cs-intl-pluralrules-DHSnqtec.js.map
