Intl.PluralRules&&typeof Intl.PluralRules.__addLocaleData=="function"&&Intl.PluralRules.__addLocaleData({data:{categories:{cardinal:["one","other"],ordinal:["one","other"]},fn:function(e,a){return a?e==1||e==5?"one":"other":e==1?"one":"other"}},locale:"hu"});
//# sourceMappingURL=hu-intl-pluralrules-DsqPMxwO.js.map
