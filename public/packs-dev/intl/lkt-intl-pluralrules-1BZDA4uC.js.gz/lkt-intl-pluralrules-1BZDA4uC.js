Intl.PluralRules&&typeof Intl.PluralRules.__addLocaleData=="function"&&Intl.PluralRules.__addLocaleData({data:{categories:{cardinal:["other"],ordinal:["other"]},fn:function(l,a){return"other"}},locale:"lkt"});
//# sourceMappingURL=lkt-intl-pluralrules-1BZDA4uC.js.map
