Intl.PluralRules&&typeof Intl.PluralRules.__addLocaleData=="function"&&Intl.PluralRules.__addLocaleData({data:{categories:{cardinal:["one","other"],ordinal:["few","other"]},fn:function(e,a){var l=String(e).split("."),r=Number(l[0])==e,t=r&&l[0].slice(-1);return a?t==6||t==9||e==10?"few":"other":e==1?"one":"other"}},locale:"tk"});
//# sourceMappingURL=tk-intl-pluralrules-DNIWtLHg.js.map
