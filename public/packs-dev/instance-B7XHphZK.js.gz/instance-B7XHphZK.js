import{b as i}from"./api-uqk9CYtW.js";const t=e=>i(e?`v1/instance/terms_of_service/${e}`:"v1/instance/terms_of_service"),a=()=>i("v1/instance/privacy_policy");export{a,t as b};
//# sourceMappingURL=instance-B7XHphZK.js.map
