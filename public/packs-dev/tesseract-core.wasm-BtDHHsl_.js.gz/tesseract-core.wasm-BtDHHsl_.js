const s="/packs-dev/assets/tesseract-core-DIekW5zv.js";export{s as default};
//# sourceMappingURL=tesseract-core.wasm-BtDHHsl_.js.map
