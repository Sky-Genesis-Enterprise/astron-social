import{g as t}from"./index-ykyyQSL-.js";import{r as o}from"./status-D92xLx8p.js";var r,a;function q(){if(a)return r;a=1;var s=o();function u(e,i){return s(e,i)}return r=u,r}var E=q();const f=t(E);export{f as i};
//# sourceMappingURL=isEqual-DEAPsZr2.js.map
