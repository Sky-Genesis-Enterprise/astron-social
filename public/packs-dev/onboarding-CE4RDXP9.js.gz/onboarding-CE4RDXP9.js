import{aM as o,aN as s}from"./useSelectableClick-DBo53LOf.js";const t=20181216044202,e=()=>n=>{n(o(["introductionVersion"],t)),n(s())};export{t as I,e as c};
//# sourceMappingURL=onboarding-CE4RDXP9.js.map
