import{r}from"./index-ykyyQSL-.js";var a=r.useLayoutEffect;export{a as i};
//# sourceMappingURL=use-isomorphic-layout-effect.browser.esm-Bg5tPKmX.js.map
