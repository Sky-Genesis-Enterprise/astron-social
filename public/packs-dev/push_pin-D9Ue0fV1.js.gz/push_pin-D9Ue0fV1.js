import{r as t}from"./index-ykyyQSL-.js";const h=v=>t.createElement("svg",{xmlns:"http://www.w3.org/2000/svg",height:24,viewBox:"0 -960 960 960",width:24,...v},t.createElement("path",{d:"m640-480 80 80v80H520v240l-40 40-40-40v-240H240v-80l80-80v-280h-40v-80h400v80h-40v280Zm-286 80h252l-46-46v-314H400v314l-46 46Zm126 0Z"}));export{h as S};
//# sourceMappingURL=push_pin-D9Ue0fV1.js.map
