Intl.PluralRules&&typeof Intl.PluralRules.__addLocaleData=="function"&&Intl.PluralRules.__addLocaleData({data:{categories:{cardinal:["one","other"],ordinal:["other"]},fn:function(a,l){return l?"other":a==1?"one":"other"}},locale:"nah"});
//# sourceMappingURL=nah-intl-pluralrules-BpBgom_x.js.map
