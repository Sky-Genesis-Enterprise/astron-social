Intl.PluralRules&&typeof Intl.PluralRules.__addLocaleData=="function"&&Intl.PluralRules.__addLocaleData({data:{categories:{cardinal:["one","other"],ordinal:["other"]},fn:function(a,l){return l?"other":a==1?"one":"other"}},locale:"ss"});
//# sourceMappingURL=ss-intl-pluralrules-Bsr-iIg8.js.map
