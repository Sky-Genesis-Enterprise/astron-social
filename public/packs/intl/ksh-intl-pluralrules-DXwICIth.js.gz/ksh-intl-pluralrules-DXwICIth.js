Intl.PluralRules&&typeof Intl.PluralRules.__addLocaleData=="function"&&Intl.PluralRules.__addLocaleData({data:{categories:{cardinal:["zero","one","other"],ordinal:["other"]},fn:function(e,a){return a?"other":e==0?"zero":e==1?"one":"other"}},locale:"ksh"});
//# sourceMappingURL=ksh-intl-pluralrules-DXwICIth.js.map
