Intl.PluralRules&&typeof Intl.PluralRules.__addLocaleData=="function"&&Intl.PluralRules.__addLocaleData({data:{categories:{cardinal:["other"],ordinal:["one","other"]},fn:function(l,a){return a&&l==1?"one":"other"}},locale:"lo"});
//# sourceMappingURL=lo-intl-pluralrules-B67ihkvk.js.map
