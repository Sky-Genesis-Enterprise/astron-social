Intl.PluralRules&&typeof Intl.PluralRules.__addLocaleData=="function"&&Intl.PluralRules.__addLocaleData({data:{categories:{cardinal:["one","other"],ordinal:["one","two","few","many","other"]},fn:function(e,a){return a?e==1?"one":e==2||e==3?"two":e==4?"few":e==6?"many":"other":e>=0&&e<=1?"one":"other"}},locale:"hi"});
//# sourceMappingURL=hi-intl-pluralrules-DfsBhdAE.js.map
