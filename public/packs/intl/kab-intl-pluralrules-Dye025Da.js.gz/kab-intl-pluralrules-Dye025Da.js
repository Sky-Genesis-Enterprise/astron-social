Intl.PluralRules&&typeof Intl.PluralRules.__addLocaleData=="function"&&Intl.PluralRules.__addLocaleData({data:{categories:{cardinal:["one","other"],ordinal:["other"]},fn:function(a,l){return l?"other":a>=0&&a<2?"one":"other"}},locale:"kab"});
//# sourceMappingURL=kab-intl-pluralrules-Dye025Da.js.map
