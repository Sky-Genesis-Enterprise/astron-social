Intl.PluralRules&&typeof Intl.PluralRules.__addLocaleData=="function"&&Intl.PluralRules.__addLocaleData({data:{categories:{cardinal:["one","other"],ordinal:["many","other"]},fn:function(a,l){var t=String(a).split("."),e=!t[1];return l?a==11||a==8||a==80||a==800?"many":"other":a==1&&e?"one":"other"}},locale:"sc"});
//# sourceMappingURL=sc-intl-pluralrules-D-jbYhem.js.map
