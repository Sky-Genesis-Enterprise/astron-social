Intl.PluralRules&&typeof Intl.PluralRules.__addLocaleData=="function"&&Intl.PluralRules.__addLocaleData({data:{categories:{cardinal:["one","other"],ordinal:["one","other"]},fn:function(e,a){return a?e==1?"one":"other":e>=0&&e<2?"one":"other"}},locale:"hy"});
//# sourceMappingURL=hy-intl-pluralrules-Br2e8hpR.js.map
