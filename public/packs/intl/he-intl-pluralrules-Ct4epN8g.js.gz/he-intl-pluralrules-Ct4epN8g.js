Intl.PluralRules&&typeof Intl.PluralRules.__addLocaleData=="function"&&Intl.PluralRules.__addLocaleData({data:{categories:{cardinal:["one","two","other"],ordinal:["other"]},fn:function(e,o){var l=String(e).split("."),t=l[0],a=!l[1];return o?"other":t==1&&a||t==0&&!a?"one":t==2&&a?"two":"other"}},locale:"he"});
//# sourceMappingURL=he-intl-pluralrules-Ct4epN8g.js.map
