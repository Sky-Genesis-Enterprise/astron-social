Intl.PluralRules&&typeof Intl.PluralRules.__addLocaleData=="function"&&Intl.PluralRules.__addLocaleData({data:{categories:{cardinal:["one","other"],ordinal:["one","other"]},fn:function(a,l){return a==1?"one":"other"}},locale:"bal"});
//# sourceMappingURL=bal-intl-pluralrules-Bw1mH8Qt.js.map
