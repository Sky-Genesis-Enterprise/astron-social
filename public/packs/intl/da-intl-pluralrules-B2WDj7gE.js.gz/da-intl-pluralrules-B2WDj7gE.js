Intl.PluralRules&&typeof Intl.PluralRules.__addLocaleData=="function"&&Intl.PluralRules.__addLocaleData({data:{categories:{cardinal:["one","other"],ordinal:["other"]},fn:function(a,e){var l=String(a).split("."),t=l[0],r=Number(l[0])==a;return e?"other":a==1||!r&&(t==0||t==1)?"one":"other"}},locale:"da"});
//# sourceMappingURL=da-intl-pluralrules-B2WDj7gE.js.map
