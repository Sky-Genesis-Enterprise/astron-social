Intl.PluralRules&&typeof Intl.PluralRules.__addLocaleData=="function"&&Intl.PluralRules.__addLocaleData({data:{categories:{cardinal:["zero","one","other"],ordinal:["other"]},fn:function(a,e){var r=String(a).split("."),l=r[0];return e?"other":a==0?"zero":(l==0||l==1)&&a!=0?"one":"other"}},locale:"lag"});
//# sourceMappingURL=lag-intl-pluralrules-CUe0XR_q.js.map
