Intl.PluralRules&&typeof Intl.PluralRules.__addLocaleData=="function"&&Intl.PluralRules.__addLocaleData({data:{categories:{cardinal:["other"],ordinal:["one","other"]},fn:function(a,l){return l&&a==1?"one":"other"}},locale:"ms"});
//# sourceMappingURL=ms-intl-pluralrules-DaljCvKK.js.map
