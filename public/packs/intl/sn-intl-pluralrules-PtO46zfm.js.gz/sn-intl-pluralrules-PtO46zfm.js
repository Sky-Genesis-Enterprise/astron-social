Intl.PluralRules&&typeof Intl.PluralRules.__addLocaleData=="function"&&Intl.PluralRules.__addLocaleData({data:{categories:{cardinal:["one","other"],ordinal:["other"]},fn:function(a,l){return l?"other":a==1?"one":"other"}},locale:"sn"});
//# sourceMappingURL=sn-intl-pluralrules-PtO46zfm.js.map
