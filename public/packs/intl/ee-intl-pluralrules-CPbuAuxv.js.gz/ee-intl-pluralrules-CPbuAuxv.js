Intl.PluralRules&&typeof Intl.PluralRules.__addLocaleData=="function"&&Intl.PluralRules.__addLocaleData({data:{categories:{cardinal:["one","other"],ordinal:["other"]},fn:function(e,a){return a?"other":e==1?"one":"other"}},locale:"ee"});
//# sourceMappingURL=ee-intl-pluralrules-CPbuAuxv.js.map
