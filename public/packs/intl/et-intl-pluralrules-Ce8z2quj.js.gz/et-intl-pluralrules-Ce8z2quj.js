Intl.PluralRules&&typeof Intl.PluralRules.__addLocaleData=="function"&&Intl.PluralRules.__addLocaleData({data:{categories:{cardinal:["one","other"],ordinal:["other"]},fn:function(a,l){var t=String(a).split("."),e=!t[1];return l?"other":a==1&&e?"one":"other"}},locale:"et"});
//# sourceMappingURL=et-intl-pluralrules-Ce8z2quj.js.map
