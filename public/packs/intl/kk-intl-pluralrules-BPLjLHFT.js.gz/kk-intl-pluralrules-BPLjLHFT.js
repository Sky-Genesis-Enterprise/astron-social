Intl.PluralRules&&typeof Intl.PluralRules.__addLocaleData=="function"&&Intl.PluralRules.__addLocaleData({data:{categories:{cardinal:["one","other"],ordinal:["many","other"]},fn:function(a,r){var e=String(a).split("."),t=Number(e[0])==a,l=t&&e[0].slice(-1);return r?l==6||l==9||t&&l==0&&a!=0?"many":"other":a==1?"one":"other"}},locale:"kk"});
//# sourceMappingURL=kk-intl-pluralrules-BPLjLHFT.js.map
