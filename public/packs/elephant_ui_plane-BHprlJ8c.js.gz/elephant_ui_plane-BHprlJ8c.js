const e="/packs/assets/elephant_ui_plane-Cfmrathl.svg";export{e};
//# sourceMappingURL=elephant_ui_plane-BHprlJ8c.js.map
