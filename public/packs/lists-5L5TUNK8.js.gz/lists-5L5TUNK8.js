import{bS as r}from"./useSelectableClick-DeaJbL2_.js";const o=r([t=>t.lists],t=>t.toList().filter(e=>!!e)),l=r([t=>o(t)],t=>t.sort((e,s)=>e.title.localeCompare(s.title)).toArray());export{l as g};
//# sourceMappingURL=lists-5L5TUNK8.js.map
