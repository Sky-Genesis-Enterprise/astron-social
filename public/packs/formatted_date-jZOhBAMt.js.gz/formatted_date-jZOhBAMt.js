import{j as r}from"./client-wT6vtYO_.js";import{b as a}from"./index-BdTwX--g.js";const m=t=>r.jsx(a,{...t,children:e=>r.jsx("time",{dateTime:n(t.value),className:t.className,children:e})}),n=t=>{if(!t)return"";try{return new Date(t).toISOString()}catch{return t.toString()}};export{m as F};
//# sourceMappingURL=formatted_date-jZOhBAMt.js.map
