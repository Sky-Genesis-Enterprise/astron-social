import{j as e}from"./client-wT6vtYO_.js";import{c as t}from"./index-DizoKcfL.js";const l=({className:r,message:s,label:i,url:n})=>e.jsxs("div",{className:t("timeline-hint",r),children:[e.jsx("p",{children:s}),e.jsx("a",{href:n,target:"_blank",rel:"noopener noreferrer",children:i})]});export{l as T};
//# sourceMappingURL=timeline_hint-0fHjsenK.js.map
