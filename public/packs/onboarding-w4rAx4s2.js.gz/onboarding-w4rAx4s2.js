import{aM as o,aN as s}from"./useSelectableClick-DeaJbL2_.js";const t=20181216044202,e=()=>n=>{n(o(["introductionVersion"],t)),n(s())};export{t as I,e as c};
//# sourceMappingURL=onboarding-w4rAx4s2.js.map
