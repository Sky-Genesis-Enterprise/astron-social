import{r as t}from"./index-BdTwX--g.js";const o=e=>t.createElement("svg",{xmlns:"http://www.w3.org/2000/svg",height:24,viewBox:"0 -960 960 960",width:24,...e},t.createElement("path",{d:"M160-120v-480l320-240 320 240v480H560v-280H400v280H160Z"}));export{o as S};
//# sourceMappingURL=home-fill-BjwEpYg3.js.map
