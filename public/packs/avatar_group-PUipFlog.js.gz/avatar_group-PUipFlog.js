import{j as r}from"./client-wT6vtYO_.js";import{c as t}from"./index-DizoKcfL.js";const c=({children:s,compact:o=!1,avatarHeight:a})=>r.jsx("div",{className:t("avatar-group",{"avatar-group--compact":o}),style:a?{"--avatar-height":`${a}px`}:void 0,children:s});export{c as A};
//# sourceMappingURL=avatar_group-PUipFlog.js.map
