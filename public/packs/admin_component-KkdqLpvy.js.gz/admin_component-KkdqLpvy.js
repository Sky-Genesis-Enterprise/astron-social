import{j as o}from"./client-wT6vtYO_.js";import{r as t}from"./index-BdTwX--g.js";import{I as e}from"./intl_provider-DvXl4eEi.js";import"./load_locale-tOpKhmcM.js";class a extends t.PureComponent{render(){const{children:r}=this.props;return o.jsx(e,{children:r})}}export{a as default};
//# sourceMappingURL=admin_component-KkdqLpvy.js.map
