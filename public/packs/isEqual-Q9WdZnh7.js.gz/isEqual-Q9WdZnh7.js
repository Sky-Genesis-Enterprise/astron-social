import{g as t}from"./index-BdTwX--g.js";import{r as o}from"./status-CiF0hsk4.js";var r,a;function q(){if(a)return r;a=1;var s=o();function u(e,i){return s(e,i)}return r=u,r}var E=q();const f=t(E);export{f as i};
//# sourceMappingURL=isEqual-Q9WdZnh7.js.map
