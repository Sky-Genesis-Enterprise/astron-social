const s="/packs/assets/tesseract-core-DIekW5zv.js";export{s as default};
//# sourceMappingURL=tesseract-core.wasm-B2697XUV.js.map
