import{b as i}from"./api-B2m7efUy.js";const t=e=>i(e?`v1/instance/terms_of_service/${e}`:"v1/instance/terms_of_service"),a=()=>i("v1/instance/privacy_policy");export{a,t as b};
//# sourceMappingURL=instance-YMWmo8KL.js.map
