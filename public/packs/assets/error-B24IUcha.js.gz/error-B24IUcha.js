import{r}from"../ready-DpOgoWSg.js";r(()=>{const e=document.querySelector("img");e&&(e.addEventListener("mouseenter",()=>{e.src="/oops.gif"}),e.addEventListener("mouseleave",()=>{e.src="/oops.png"}))}).catch(e=>{console.error(e)});
//# sourceMappingURL=error-B24IUcha.js.map
