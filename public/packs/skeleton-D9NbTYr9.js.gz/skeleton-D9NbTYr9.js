import{j as t}from"./client-wT6vtYO_.js";const n=({width:s,height:e})=>t.jsx("span",{className:"skeleton",style:{width:s,height:e},children:"‌"});export{n as S};
//# sourceMappingURL=skeleton-D9NbTYr9.js.map
