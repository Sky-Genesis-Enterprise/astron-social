import{r}from"./index-BdTwX--g.js";var a=r.useLayoutEffect;export{a as i};
//# sourceMappingURL=use-isomorphic-layout-effect.browser.esm-D-sFEUJ5.js.map
